import { Pipe, PipeTransform } from "@angular/core";




@Pipe({
    name:'mycustompipe'
})
export class MyCustomPipe implements PipeTransform
{
    transform(value: any, ...args: any[])
    {
       return ")"+args[0]+args[1];
            
    }
}
        //throw new Error("Method not implemented.");
    
    