import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name:'toPercent'
})
export class ToPercent implements PipeTransform{
    transform(value: any, ...args: any[]) {
       return value/100+args[0];
    }

}