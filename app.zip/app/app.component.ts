import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import MyfirstCalcService from './first.service';


interface IData{
  date:Date,
  temperatureC:number,
  summary:string,
  temperatureF:number

}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  constructor(private http:HttpClient){
  
   

  }
  Add(){
    this.http.get<IData[]>("https://localhost:44378/weatherforecast").subscribe(data=>{console.log(data[0].summary)},err=>console.log(err));
  }
  
  PostData(){
    var res:IData ={
      temperatureC:34,
      temperatureF:109,
      summary:"data",
      date:new Date()
    }
    this.http.post<IData>("https://localhost:44378/weatherforecast/savedata",res).subscribe(val=>console.log(val),err=>console.log(err));
  }
  DelData(){
    this.http.delete("https://localhost:44378/weatherforecast/deletedata/2").subscribe(dat=>console.log(dat));
  }
  UpData(){
    var res:IData ={
      temperatureC:34,
      temperatureF:109,
      summary:"data",
      date:new Date()
    }
    this.http.put("https://localhost:44378/weatherforecast/updata/2",res).subscribe(x=>console.log(x));
  }
}
