import { Component, OnInit } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import { HttpClient } from '@angular/common/http';


interface IData {
  date:string,
  temperatureC:string,
  temperatureF:string,
  summary:string
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  date:string="";
  summary:string="";
  tempc:string="";
  tempf:string="";

  constructor(private http:HttpClient){
   
  }
  ngOnInit(): void {
   this.http.get<IData[]>("https://localhost:44344/weatherforecast").subscribe(data=>{
    
   this.date = data[0].date,
   this.summary = data[1].summary,
   this.tempc = data[2].temperatureC,
   this.tempf = data[3].temperatureF
   }) 
  }
  title = 'http-app';

   UpdateData(){
     var res:IData =
     {
      date  :this.date,
      temperatureC : this.tempc,
      temperatureF: this.tempf,
      summary : this.summary
     }
    this.http.put<IData>("https://localhost:44344/weatherforecast/update/"+this.tempf,res).subscribe(data=>{
    });
}

}
