import { Component } from '@angular/core';

import MyfirstCalcService from './first.service';

@Component({
  selector: 'app-demo',
  template: '<button (click)="AddAgain()">Add Again</button>',
  
})
export default class DemoComponent {
  constructor(private calc:MyfirstCalcService){
  
   

  }
  AddAgain(){
    console.log(this.calc.Add(23,23));
  }
  
}
