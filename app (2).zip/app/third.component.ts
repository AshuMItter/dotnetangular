import { Component } from '@angular/core';


@Component({
    selector:'app-three',
    template:'<h1>This is for Wild Card </h1>' 
})
export default class ThirdComponent{

}