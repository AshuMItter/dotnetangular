import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import FirstComponent from './first.component';
import FormComponent from './form.component';
import TrapingTheRouteComponent from './fourth.component';
import SecondComponent from './second.component';
import ThirdComponent from './third.component';

const routes: Routes = [
{path:'', component: FirstComponent},
{path:'about', component:SecondComponent},
{path:'form',component:FormComponent},
{path:'product/:id',component: TrapingTheRouteComponent},
{path:'**', component:ThirdComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
