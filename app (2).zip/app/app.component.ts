import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  list:any[] = [{name:'Product 12',url:'/product',id:12},
  {name:'Product 13',url:'/product',id:13},
  {name:'Product 14',url:'/product',id:14},
  {name:'Product 15',url:'/product',id:15},
  {name:'Product 16',url:'/product',id:16}
                ]
  
}
