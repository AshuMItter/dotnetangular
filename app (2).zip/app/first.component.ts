import { Component } from '@angular/core';


@Component({
    selector:'app-one',
    template:'<h1>This is Home Component' 
})
export default class FirstComponent{
    constructor(){
        console.warn("First Component");
    }

}