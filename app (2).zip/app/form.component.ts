import { Component } from '@angular/core';
import { FormGroup, FormControl,Validator, Validators } from '@angular/forms';​


@Component({
    selector:'app-one',
    templateUrl:'./form.component.html' 
})
export default class FormComponent{
   
     formprofile = new FormGroup({
        username : new FormControl('',Validators.email),
        password: new FormControl('')

     })

    submit(){
        if(this.formprofile.valid == true){
         console.log(this.formprofile.controls['username'].value);
         console.log(this.formprofile.controls['password'].value);
        }
        else{
            console.log("error");
        }
      }

}