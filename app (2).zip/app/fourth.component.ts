import { Component, DoCheck, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { ActivatedRoute } from '@angular/router';



@Component({
    selector:'app-two',
    template:'<h1>This is RouteTraped Component{{id}}</h1>' 
})
export default class TrapingTheRouteComponent implements OnInit, DoCheck, OnChanges {
 
    id:string|null="";
    constructor(private route: ActivatedRoute){

      console.warn("TrapingTheRouteComponent");
    }
    ngOnChanges(changes: SimpleChanges): void {
      
    }
    ngDoCheck(): void {
        this.id =   this.route.snapshot.paramMap.get("id");
        console.log(this.id); 
    }
    ngOnInit(): void {
       
    }

    
   
     
}