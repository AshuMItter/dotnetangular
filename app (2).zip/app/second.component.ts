import { Component } from '@angular/core';


@Component({
    selector:'app-two',
    template:'<h1>This is About Component' 
})
export default class SecondComponent{
    constructor(){
        console.warn("Second Controller")
    }
}