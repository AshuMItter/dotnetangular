import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-selfgenerated',
  templateUrl: './selfgenerated.component.html',
  styleUrls: ['./selfgenerated.component.css']
})
export class SelfgeneratedComponent implements OnInit {

  age:number = 34;
 // val:string ="btn btn-primary";
  styl:string = "background-color:red;"

  names:string[] = ["Nikhil","Ashu","Amit","Amir","Nusrat","Rucha","Sachin","Omkar","Meet","Irum"]

  data:string = "Your name here";
  constructor() { }

  save(){
    alert("demo");
  }
  ngOnInit(): void {
  }

}
