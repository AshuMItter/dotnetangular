import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SelfgeneratedComponent } from './selfgenerated.component';

describe('SelfgeneratedComponent', () => {
  let component: SelfgeneratedComponent;
  let fixture: ComponentFixture<SelfgeneratedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SelfgeneratedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SelfgeneratedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
